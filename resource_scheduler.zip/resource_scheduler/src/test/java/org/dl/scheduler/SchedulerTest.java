package org.dl.scheduler;

import junit.framework.TestCase;
import org.dl.resource.Gateway;
import org.dl.resource.GatewayImpl;
import org.junit.*;

public class SchedulerTest extends TestCase{ 

	public Gateway  initTest()
	{
		//The number of resource to run the program
		int resourceAvailable=3;
		
		//Creating the Gateway object
		Gateway gateway =new GatewayImpl(resourceAvailable);
		
		return gateway;
	}
	
	@Test
	public void testMessageOrderOriginal() throws TerminationException
	{
		
		Gateway gateway=this.initTest();
		
		//Creating the possible strategy object
		MessagePrioritisation messagePrioritisationOriginal=new MessagePrioritisationImplOriginal();
		
		//Creating Scheduler object Thread with the Strategy object you want to have
		Scheduler scheduler = new Scheduler(gateway,messagePrioritisationOriginal);
		
		scheduler.receiveMessage(new MessageImpl(2,1,false));
		scheduler.receiveMessage(new MessageImpl(1,2,false));
		scheduler.receiveMessage(new MessageImpl(2,3,false));
		scheduler.receiveMessage(new MessageImpl(3,4,false));
		
		assertTrue(messagePrioritisationOriginal.getNextMessage().getMessageId()==1 
				& messagePrioritisationOriginal.getNextMessage().getMessageId()==3
				& messagePrioritisationOriginal.getNextMessage().getMessageId()==2
				& messagePrioritisationOriginal.getNextMessage().getMessageId()==4);
	}
	
	@Test
	public void testMessageOrderFIFO() throws TerminationException
	{
		Gateway gateway=this.initTest();
		
		//Creating the possible strategy object
		MessagePrioritisation messagePrioritisationFIFO=new MessagePrioritisationImplFIFO();
		
		//Creating Scheduler object Thread with the Strategy object you want to have
		Scheduler scheduler = new Scheduler(gateway,messagePrioritisationFIFO);
		
		scheduler.receiveMessage(new MessageImpl(2,1,false));
		scheduler.receiveMessage(new MessageImpl(1,2,false));
		scheduler.receiveMessage(new MessageImpl(2,3,false));
		scheduler.receiveMessage(new MessageImpl(3,4,false));
		
		assertTrue(messagePrioritisationFIFO.getNextMessage().getMessageId()==1 
				& messagePrioritisationFIFO.getNextMessage().getMessageId()==2
				& messagePrioritisationFIFO.getNextMessage().getMessageId()==3
				& messagePrioritisationFIFO.getNextMessage().getMessageId()==4);
	}
	
	@Test
	public void testGroupCancellation_1() throws TerminationException
	{
		Gateway gateway=this.initTest();
		
		//Creating the possible strategy object
		MessagePrioritisation messagePrioritisationOriginal=new MessagePrioritisationImplOriginal();
		
		//Creating Scheduler object Thread with the Strategy object you want to have
		Scheduler scheduler = new Scheduler(gateway,messagePrioritisationOriginal);

		scheduler.receiveMessage(new MessageImpl(2,1,false));
		scheduler.receiveMessage(new MessageImpl(1,2,false));
		scheduler.receiveMessage(new MessageImpl(2,3,false));
		scheduler.receiveMessage(new MessageImpl(3,4,false));
		
		messagePrioritisationOriginal.cancelGroup(1);
		
		assertTrue(messagePrioritisationOriginal.getNextMessage().getMessageId()==1 
				& messagePrioritisationOriginal.getNextMessage().getMessageId()==3
				& messagePrioritisationOriginal.getNextMessage().getMessageId()==4);
	}
	
	@Test
	public void testGroupCancellation_2_V1() throws TerminationException
	{
		Gateway gateway=this.initTest();
		
		//Creating the possible strategy object
		MessagePrioritisation messagePrioritisationOriginal=new MessagePrioritisationImplOriginal();
		
		//Creating Scheduler object Thread with the Strategy object you want to have
		Scheduler scheduler = new Scheduler(gateway,messagePrioritisationOriginal);

		scheduler.receiveMessage(new MessageImpl(2,1,false));
		scheduler.receiveMessage(new MessageImpl(1,2,false));
		
		messagePrioritisationOriginal.cancelGroup(2);
		
		scheduler.receiveMessage(new MessageImpl(2,3,false));
		scheduler.receiveMessage(new MessageImpl(3,4,false));
		
		assertTrue(messagePrioritisationOriginal.getNextMessage().getMessageId()==2 
				& messagePrioritisationOriginal.getNextMessage().getMessageId()==4);
	}
	
	@Test
	public void testGroupCancellation_2_V2() throws TerminationException
	{
		Gateway gateway=this.initTest();
		
		//Creating the possible strategy object
		MessagePrioritisation messagePrioritisationOriginal=new MessagePrioritisationImplOriginal();
		
		//Creating Scheduler object Thread with the Strategy object you want to have
		Scheduler scheduler = new Scheduler(gateway,messagePrioritisationOriginal);

		scheduler.receiveMessage(new MessageImpl(2,1,false));
		scheduler.receiveMessage(new MessageImpl(1,2,false));
		scheduler.receiveMessage(new MessageImpl(2,3,false));
		scheduler.receiveMessage(new MessageImpl(3,4,false));
		
		messagePrioritisationOriginal.cancelGroup(2);
		
		assertTrue(messagePrioritisationOriginal.getNextMessage().getMessageId()==2 
				& messagePrioritisationOriginal.getNextMessage().getMessageId()==4);
	}
	
	@Test
	public void testGroupCancellation_2_V3() throws TerminationException
	{
		Gateway gateway=this.initTest();
		
		//Creating the possible strategy object
		MessagePrioritisation messagePrioritisationOriginal=new MessagePrioritisationImplOriginal();
		
		//Creating Scheduler object Thread with the Strategy object you want to have
		Scheduler scheduler = new Scheduler(gateway,messagePrioritisationOriginal);

		messagePrioritisationOriginal.cancelGroup(2);
		
		scheduler.receiveMessage(new MessageImpl(2,1,false));
		scheduler.receiveMessage(new MessageImpl(1,2,false));
		scheduler.receiveMessage(new MessageImpl(2,3,false));
		scheduler.receiveMessage(new MessageImpl(3,4,false));
		
		assertTrue(messagePrioritisationOriginal.getNextMessage().getMessageId()==2 
				& messagePrioritisationOriginal.getNextMessage().getMessageId()==4);
	}
	
	@Test
	public void testTerminationMessage() throws TerminationException
	{
		Gateway gateway=this.initTest();
		
		//Creating the possible strategy object
		MessagePrioritisation messagePrioritisationOriginal=new MessagePrioritisationImplOriginal();
		
		//Creating Scheduler object Thread with the Strategy object you want to have
		Scheduler scheduler = new Scheduler(gateway,messagePrioritisationOriginal);

		scheduler.receiveMessage(new MessageImpl(2,1,true));
		scheduler.receiveMessage(new MessageImpl(1,2,false));
		
		try {
			scheduler.receiveMessage(new MessageImpl(2,3,false));
			fail( "My method didn't throw when I expected it to" );
		} catch (TerminationException expectedException) {
			System.out.println(expectedException.getMessage());
		}
	}
	
	@Test
	public void testMessageQueuingOneResouce() throws TerminationException
	{
		
		//The number of resource to run the program
		int resourceAvailable=1;
		
		//Creating the Gateway object
		Gateway gateway =new GatewayImpl(resourceAvailable);
		//System.out.println("TAILLe="+gateway.getResourceManager().getQueueSize());
		 
		//Creating the possible strategy object
		MessagePrioritisation messagePrioritisationOriginal=new MessagePrioritisationImplOriginal();
		
		//Creating Scheduler object Thread with the Strategy object you want to have
		Scheduler scheduler = new Scheduler(gateway,messagePrioritisationOriginal);
		
		//Creating the GenerateMessage object Thread
		GenerateMessage generateMessage=new GenerateMessage(scheduler);
		
		gateway.startResource();
		scheduler.start();
		
		
		scheduler.receiveMessage(new MessageImpl(2,1,false));
		scheduler.receiveMessage(new MessageImpl(2,3,false));
		
		//Need to wait to let the message go through the gateway
		generateMessage.sleepForTestingPurpose(100);
		
		assertTrue(messagePrioritisationOriginal.ContainsMessageId(3L)==true 
				&& messagePrioritisationOriginal.ContainsMessageId(1L)==false);
	}
	
	
}
