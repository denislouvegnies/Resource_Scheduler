package org.dl.scheduler;

import org.dl.resource.Gateway;
import org.dl.resource.GatewayImpl;
import org.junit.Test;

import junit.framework.TestCase;

public class ScheduletTest2  extends TestCase{ 

	@Test
	public void testMessageForwardingOneResouce() throws TerminationException
	{
		
		//The number of resource to run the program
		int resourceAvailable=1;
		
		//Creating the Gateway object
		Gateway gateway =new GatewayImpl(resourceAvailable);
		
		//Creating the possible strategy object
		MessagePrioritisation messagePrioritisationOriginal=new MessagePrioritisationImplOriginal();
		
		//Creating Scheduler object Thread with the Strategy object you want to have
		Scheduler scheduler = new Scheduler(gateway,messagePrioritisationOriginal);
		
		//Creating the GenerateMessage object Thread
		GenerateMessage generateMessage=new GenerateMessage(scheduler);
		
		gateway.startResource();
		scheduler.start();
		
		scheduler.receiveMessage(new MessageImpl(2,1,false));
		
		//Need to wait to let the message go through the gateway
		generateMessage.sleepForTestingPurpose(200);
		
		assertTrue(messagePrioritisationOriginal.ContainsMessageId(1L)==false);
	}

	@Test
	public void testMessageForwardingTwoResouces() throws TerminationException
	{
		
		//The number of resource to run the program
		int resourceAvailable=2;
		
		//Creating the Gateway object
		Gateway gateway =new GatewayImpl(resourceAvailable);
		 
		//Creating the possible strategy object
		MessagePrioritisation messagePrioritisationOriginal=new MessagePrioritisationImplOriginal();
		
		//Creating Scheduler object Thread with the Strategy object you want to have
		Scheduler scheduler = new Scheduler(gateway,messagePrioritisationOriginal);
		
		//Creating the GenerateMessage object Thread
		GenerateMessage generateMessage=new GenerateMessage(scheduler);
		
		gateway.startResource();
		scheduler.start();
		
		
		scheduler.receiveMessage(new MessageImpl(2,1,false));
		scheduler.receiveMessage(new MessageImpl(2,3,false));
		
		//Need to wait to let the message go through the gateway
		generateMessage.sleepForTestingPurpose(400);
		
		assertTrue(messagePrioritisationOriginal.ContainsMessageId(1L)==false 
				&& messagePrioritisationOriginal.ContainsMessageId(3L)==false );
	}

	@Test
	public void testMessageQueuingZeroResouce() throws TerminationException
	{
		
		//The number of resource to run the program
		int resourceAvailable=1;
		
		//Creating the Gateway object
		Gateway gateway =new GatewayImpl(resourceAvailable);
		//System.out.println("TAILLe="+gateway.getResourceManager().getQueueSize());
		 
		//Creating the possible strategy object
		MessagePrioritisation messagePrioritisationOriginal=new MessagePrioritisationImplOriginal();
		
		//Creating Scheduler object Thread with the Strategy object you want to have
		Scheduler scheduler = new Scheduler(gateway,messagePrioritisationOriginal);
		
		//Creating the GenerateMessage object Thread
		GenerateMessage generateMessage=new GenerateMessage(scheduler);
		
	
		//gateway.startResource(); 	//No resource started 
		scheduler.start();
		
		
		scheduler.receiveMessage(new MessageImpl(2,1,false));
		scheduler.receiveMessage(new MessageImpl(2,3,false));
		
		//Need to wait to let the message go through the gateway
		generateMessage.sleepForTestingPurpose(100);
		
		assertTrue(messagePrioritisationOriginal.ContainsMessageId(1L)==true 
				&& messagePrioritisationOriginal.ContainsMessageId(3L)==true);
	}

}
