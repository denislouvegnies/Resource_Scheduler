package org.df.resource;

import org.dl.resource.Gateway;
import org.dl.resource.GatewayImpl;
import org.dl.resource.WaitingMessage;
import org.dl.scheduler.MessageImpl;
import org.dl.scheduler.MessagePrioritisation;
import org.dl.scheduler.MessagePrioritisationImplOriginal;
import org.dl.scheduler.Scheduler;
import org.dl.scheduler.TerminationException;
import org.junit.Test;

import junit.framework.TestCase;

public class ResourceTest  extends TestCase {
	
	@Test
	public void testIfMessageIsReceivedFromScheduler() throws TerminationException, InterruptedException
	{
		//The number of resource to run the program
		final int resourceAvailable=1;
		
		//Creating the Gateway object
		Gateway gateway =new GatewayImpl(resourceAvailable);
		
		//Creating the possible strategy object
		MessagePrioritisation messagePrioritisationOriginal=new MessagePrioritisationImplOriginal();
		
		//Creating Scheduler object Thread with the Strategy object you want to have
		Scheduler scheduler = new Scheduler(gateway,messagePrioritisationOriginal);
		
		
		gateway.startResource();
		scheduler.start();
		
		scheduler.receiveMessage(new MessageImpl(2,1,false));
		
		Thread.sleep(100);
		
		WaitingMessage waitingMessage=WaitingMessage.getInstance();
		assertTrue(waitingMessage.isInHistoryQueue(1L) && waitingMessage.isInHistoryQueueAndPosition(1L,1));
							
	}
	
	@Test
	public void testIfMessageIsReceivedFromSchedulerInCorrectOrder() throws TerminationException, InterruptedException
	{
		//The number of resource to run the program
		final int resourceAvailable=1;
		
		//Creating the Gateway object
		Gateway gateway =new GatewayImpl(resourceAvailable);
		
		//Creating the possible strategy object
		MessagePrioritisation messagePrioritisationOriginal=new MessagePrioritisationImplOriginal();
		
		//Creating Scheduler object Thread with the Strategy object you want to have
		Scheduler scheduler = new Scheduler(gateway,messagePrioritisationOriginal);
			
		gateway.startResource();
		scheduler.start();
		
		scheduler.receiveMessage(new MessageImpl(2,1,false));
		scheduler.receiveMessage(new MessageImpl(1,2,false));
		scheduler.receiveMessage(new MessageImpl(2,3,false));
		scheduler.receiveMessage(new MessageImpl(3,4,false));
		
		//Need time to let the messages been proceeded
		Thread.sleep(5000);
		
		WaitingMessage waitingMessage=WaitingMessage.getInstance();
		
		assertTrue(waitingMessage.isInHistoryQueueAndPosition(1L,1)
				&& waitingMessage.isInHistoryQueueAndPosition(3L,2)
				&& waitingMessage.isInHistoryQueueAndPosition(2L,3)
				&& waitingMessage.isInHistoryQueueAndPosition(4L,4)
				);
							
	}

	
	
}
