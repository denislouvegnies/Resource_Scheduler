package org.dl.scheduler;


//The message Implementation
//3 parameters :

//1 : groupe_id
//2 : message_id
//3 : isTerminationMessage : True or false if this is the final message of the group

public class MessageImpl implements Message {
	
	private long group_id;
	private long message_id;
	private boolean isTerminationMessage;
	
	
	public MessageImpl(long groupe_id, long message_id, boolean isTerminationMessage)
	{
		this.group_id=groupe_id;
		this.message_id=message_id;
		this.isTerminationMessage=isTerminationMessage;
	}
	
	@Override
	public void completed()
	{
		System.out.println("COMPLETED Message ID "+ message_id +" From Group ID "+group_id);
		
	}
	
	@Override
	public long getGroupId()
	{
		return group_id;
	}
	
	@Override
	public long getMessageId()
	{
		return message_id;
	}
	
	@Override
	public boolean getIsTerminationMessage()
	{
		return isTerminationMessage;
	}
	
}
