package org.dl.scheduler;

//Thread used to send messages to the Scheduler
//there are :
//a manual way generate_message_manual()
//and random way : generate_message(int nb_message)
//change the comment in the run() method


public class GenerateMessage extends Thread {
	
	private Scheduler scheduler;
	
	public GenerateMessage(Scheduler scheduler)
	{
		this.scheduler=scheduler;
	}
	
	//Random way to send message to the scheduler
	public void generate_message(int nb_message) throws TerminationException
	{
		for (long i=0; i<nb_message;i++)
		{
			double group_id=1 + Math.random()*10;
			Message msg=new MessageImpl((long)group_id,i,false);
			scheduler.receiveMessage(msg);
		}
	}
	
	//Manal way to send message to the scheduler
	public void generate_message_manual() throws TerminationException
	{
		scheduler.receiveMessage(new MessageImpl(2,1,false));
		scheduler.receiveMessage(new MessageImpl(1,2,false));
		scheduler.receiveMessage(new MessageImpl(2,3,false));
		scheduler.receiveMessage(new MessageImpl(3,4,false));
		//scheduler.receiveMessage(new MessageImpl(1,5,false));
	}
	
	public void sleepForTestingPurpose(int time)
	{
		try {
			sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void run ()
	{ 
		try {
			//Select here how you want to send messages to scheduler
			this.generate_message_manual();
			//this.generate_message(40);
			
	        //System.out.println("End of generator");
		}
		catch (TerminationException e){}
	}

}
