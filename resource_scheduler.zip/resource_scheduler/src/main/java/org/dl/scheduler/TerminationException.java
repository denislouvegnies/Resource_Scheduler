package org.dl.scheduler;

@SuppressWarnings("serial")
public class TerminationException extends Exception {

	public TerminationException() { super(); }
	public TerminationException(String message) { super(message); }
	public TerminationException(String message, Throwable cause) { super(message, cause); }
	public TerminationException(Throwable cause) { super(cause); }
}
