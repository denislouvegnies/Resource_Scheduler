package org.dl.scheduler;

import java.util.LinkedList;

//Another strategy for ordering the message
public class MessagePrioritisationImplFIFO implements  MessagePrioritisation{
	
	private LinkedList<Message> MessageListFIFO;
	
	public MessagePrioritisationImplFIFO()
	{
		MessageListFIFO = new LinkedList<Message>();
	}

	@Override
	public synchronized void addMessage(Message msg) throws TerminationException
	{
		MessageListFIFO.add(msg);
	}
	
	
	@Override
	public synchronized Message getNextMessage()
	{
		if (MessageListFIFO.isEmpty()==false)
		{
			return MessageListFIFO.removeFirst();
		}
		else 
		{
			return null;
		}
	}
	
	@Override
	public void cancelGroup(long group_id)
	{
		//TODO
	}
	
	@Override
	public boolean hasMoreMessage()
	{
		return MessageListFIFO.isEmpty()==false;
	}
	
	@Override
	public  boolean ContainsMessageId(long messageId)
	{
		//todo
		return true;
	}

}
