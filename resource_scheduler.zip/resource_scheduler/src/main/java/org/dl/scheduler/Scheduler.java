package org.dl.scheduler;

import org.apache.log4j.Logger;
import org.dl.resource.Gateway;

//The main class of the schedule process
//It needs a gateway and a strategy for the message prioritisation
public class Scheduler extends Thread {
	
	final static Logger log = Logger.getLogger(Main.class.getName());
	
	private MessagePrioritisation messagePrioritisation; //Used for the prioritisation Strategy
	private Gateway gateway;
	
	//Constructor
	public Scheduler(Gateway gateway,MessagePrioritisation messagePrioritisation )
	{
		this.messagePrioritisation=messagePrioritisation;
		this.gateway=gateway;
	}

	//Receive a message from outside. Put it into the messagePrioritisation Object
	public void receiveMessage(Message msg) throws TerminationException
	{
		messagePrioritisation.addMessage(msg);
		//System.out.println("Message received "+msg.getGroupId());
	}
	
	
	//Send Message to the Gateway as soon as the resource is available
	public  void sendMessage()
	{
		//Wait for a free resource before sending a new message
		//System.out.println("Wait for free ressource");
		gateway.waitForFreeResource();
		Message nextMessage=messagePrioritisation.getNextMessage();
		if (nextMessage!=null)
		{
			log.debug("sendMessage " + nextMessage.getMessageId());
			gateway.send(nextMessage);
			//System.out.println("Message sent to gateway "+nextMessage.getMessageId());
		}
	}
	
	
	
	public void run ()
	{ 
		try {
			sleep(1);
			//Uncomment to test group cancellation
			//messagePrioritisation.cancelGroup(2);
		} catch (InterruptedException e) {
			log.error("Sorry, something wrong!", e);
			e.printStackTrace();
		}
		while (!interrupted())
		{
			sendMessage();	
			//check_if_finish();
		}
	}
	
	//Stop the Scheduler Thread
	public void end()
	{
		try 
		{
			this.interrupt();
	        this.join(); 
	        System.out.println("Scheduler stopped");
		} catch (InterruptedException e) {
			log.error("Sorry, something wrong!", e);
			Thread.currentThread().interrupt();
		}
	}
	
}
