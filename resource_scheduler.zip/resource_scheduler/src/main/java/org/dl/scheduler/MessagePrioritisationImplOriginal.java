package org.dl.scheduler;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;


//Implement the strategy describe in the original specification
//the idea is to order the message when the scheduler receives it so it is easy to which message to send next to the Gateway
public class MessagePrioritisationImplOriginal implements  MessagePrioritisation{

	private LinkedHashMap<Long,LinkedList<Message>> MessageListByGroup;
	private HashMap<Long,String> TerminationList;
	
	
	public MessagePrioritisationImplOriginal()
	{
		MessageListByGroup =new LinkedHashMap<Long,LinkedList<Message>>();
		TerminationList = new HashMap<Long,String>();
	}
	
	@Override
	public synchronized void addMessage(Message msg) throws TerminationException
	{
		long group_id=msg.getGroupId();
		
		//Check if the group is not Terminated
		if (TerminationList.containsKey(group_id)==false)
		{
			//Check if the group ID already exists
			if (MessageListByGroup.containsKey(group_id)==false) //doesn't exist
			{
				//First message for this group
				LinkedList<Message> ListMessage=new LinkedList<Message>();
				ListMessage.add(msg);
				MessageListByGroup.put(group_id,ListMessage);
			}
			else //Group already exists. Need to check if the group has been canceled ie: LinkedList==null
			{
				LinkedList<Message> ListMessage=MessageListByGroup.get(group_id);
				if (ListMessage!=null) // The group hasn't been canceled
				{
					ListMessage.add(msg);
				}
			}
			//Check if it is the final message for that group
			if (msg.getIsTerminationMessage()==true)
			{
				TerminationList.put(group_id, "terminated");
			}
		}
		//The group is already terminated
		else
		{
			throw new TerminationException("TerminationException for Group id=" +group_id); 
		}
	}
	
	//return the next message that should be sent to the gateway
	//Return null if no available message
	@Override
	public synchronized Message getNextMessage()
	{
		Iterator<Long> cursor=MessageListByGroup.keySet().iterator();
		//get the list of messages of the first available group and then get the first message of that list
		while (cursor.hasNext())
		{
			//get the list of messages of the first available group and then get the first message of that list
			LinkedList<Message> ListMessage=MessageListByGroup.get(cursor.next());
			if (ListMessage!=null && ListMessage.isEmpty()==false)
			{
				return ListMessage.removeFirst();
			}
		}
		return null;
	}
	
	//Used to cancel a Group.
	public synchronized void cancelGroup(long group_id)
	{
		//Check if the group ID already exists
		if (MessageListByGroup.containsKey(group_id)==false)
		{
			//The group doesn't exist : Create the group and set the messageList to null
			MessageListByGroup.put(group_id,null);
		}
		else //Group already exists. Set the  LinkedList to null
		{
			MessageListByGroup.remove(group_id);
			MessageListByGroup.put(group_id,null);
			System.out.println("cancelGroup "+group_id);
		}
	}
	
	
	public synchronized boolean hasMoreMessage()
	{
		Iterator<Long> cursor=MessageListByGroup.keySet().iterator();
		//get the list of messages of the first available group and then get the first message of that list
		while (cursor.hasNext())
		{
			//get the list of messages of the first available group and then get the first message of that list
			LinkedList<Message> ListMessage=MessageListByGroup.get(cursor.next());
			if (ListMessage!=null && ListMessage.isEmpty()==false)
			{
				return true;
			}
		}
		return false;
	}
	
	public synchronized boolean ContainsMessageId(long messageId)
	{
		Iterator<Long> cursor=MessageListByGroup.keySet().iterator();
		//get the list of messages of the first available group 
		while (cursor.hasNext())
		{
			//get the list of messages of the first available group and then get the first message of that list
			LinkedList<Message> ListMessage=MessageListByGroup.get(cursor.next());
			if (ListMessage!=null && ListMessage.isEmpty()==false)
			{
				Iterator<Message> iteratorMessage=ListMessage.iterator();
				while(iteratorMessage.hasNext())
				{
					Message msg=iteratorMessage.next();
					if (msg.getMessageId()==messageId)
					{
						return true;
					}
				}
			}
		}
		return false;
	}
	
}
