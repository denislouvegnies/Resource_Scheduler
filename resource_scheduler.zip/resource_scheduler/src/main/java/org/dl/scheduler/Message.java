package org.dl.scheduler;

public interface Message {
	public void completed();
	public long getGroupId();
	public long getMessageId();
	public boolean getIsTerminationMessage();
}
