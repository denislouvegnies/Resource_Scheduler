package org.dl.scheduler;

public interface MessagePrioritisation {
	public void addMessage(Message msg) throws TerminationException;
	public Message getNextMessage();
	public void cancelGroup(long group_id);
	public  boolean hasMoreMessage();
	public  boolean ContainsMessageId(long messageId);
}
