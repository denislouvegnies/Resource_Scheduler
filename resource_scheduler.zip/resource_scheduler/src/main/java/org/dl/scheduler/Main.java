package org.dl.scheduler;


import org.dl.resource.Gateway;
import org.dl.resource.GatewayImpl;
import org.apache.log4j.Logger;

public class Main {
	
	final static Logger log = Logger.getLogger(Main.class.getName());
	
	public synchronized static void main (String[] arg) throws InterruptedException
	{
		//The number of resource to run the program
		final int resourceAvailable=2; //Must be >0
		
		if (resourceAvailable>0)
		{
			//Creating the Gateway object
			Gateway gateway =new GatewayImpl(resourceAvailable);
			
			//Creating the possible strategy object & Scheduler
			//Creating Scheduler object Thread with the Strategy object you want to have
			
			//ALGORITHM 1
			MessagePrioritisation messagePrioritisationOriginal=new MessagePrioritisationImplOriginal();
			Scheduler scheduler = new Scheduler(gateway,messagePrioritisationOriginal);
			
			
			//ALGORITHM 2
			//MessagePrioritisation messagePrioritisationFIFO=new MessagePrioritisationImplFIFO();
			//Scheduler scheduler = new Scheduler(gateway,messagePrioritisationFIFO);
			
			
			//Creating the GenerateMessage object Thread
			GenerateMessage generateMessage=new GenerateMessage(scheduler);
			
			log.debug("Starting generateMessage & scheduler Thread");
			gateway.startResource();
			generateMessage.start();
			scheduler.start();
			
			
			Thread.sleep(8000);
			scheduler.end();
			gateway.stopResource();
		}
		
		
	}

}
