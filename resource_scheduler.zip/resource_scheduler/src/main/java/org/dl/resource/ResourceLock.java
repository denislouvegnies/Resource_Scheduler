package org.dl.resource;

import org.apache.log4j.Logger;

//Used to know if there are available resources (Worker) so the Scheduler can send a message to the Gateway

public class ResourceLock {

	private int ResourceAvailable;
	private int totalResource;
	
	private static ResourceLock resourceLock = null;
	
	final static Logger log = Logger.getLogger(ResourceLock.class.getName());
	
	private ResourceLock()
	{
		this.ResourceAvailable=0;
	}
	
	public static synchronized  ResourceLock getInstance()
	{			
		if (resourceLock == null)
		{ 	resourceLock = new ResourceLock();	
		}
		return resourceLock;
	}
	
	/*
	public synchronized void setResourceAvailable(int totalResource)
	{
		this.totalResource=totalResource;
		ResourceAvailable=totalResource;
	}*/
	
	public synchronized void removeResource()
	{
		ResourceAvailable--;
	}
	
	public synchronized void addResource()
	{
		ResourceAvailable++;
		//System.out.println("addResource Free= "+ResourceAvailable);
		notifyAll();
	}
	
	public synchronized boolean hasFreeResource()
	{
		return ResourceAvailable>0;
	}
	
	public synchronized int getResourceAvailable()
	{
		return ResourceAvailable;
	}
	
	public synchronized void waitForFreeResource()
	{
		while(ResourceAvailable==0)
		{
			try {
				//System.out.println("I wait");
				wait();
				//System.out.println("I stop waiting");
			} 
			catch (InterruptedException e) {
				log.error("Sorry, something wrong!", e);
				e.printStackTrace();
			}
		}
		
	}
	
	public synchronized boolean isAllResourceFree()
	{
		return totalResource==ResourceAvailable;
	}
	
}
