package org.dl.resource;

import org.apache.log4j.Logger;
import org.dl.scheduler.Message;

public class GatewayImpl implements Gateway{
	
	public ResourceManager resouceManager;
	ResourceLock resourceLock=ResourceLock.getInstance();
	
	final static Logger log = Logger.getLogger(GatewayImpl.class.getName());
	
	public GatewayImpl(int resourceAvailable)
	{
		this.resouceManager=new ResourceManager(resourceAvailable);
		//resourceLock.setResourceAvailable(resourceAvailable);
	}
	
	public void startResource()
	{
		resouceManager.start_work();
	}
	
	public void stopResource()
	{
		resouceManager.stop_work();
	}
	
	
	public ResourceManager getResourceManager()
	{
		return this.resouceManager;
	}
	
	//Send message to the resource manager
	public void send(Message msg) 
	{
		try {
			resouceManager.receiveMessage(msg);
		} catch (InterruptedException e) {
			e.printStackTrace();
			log.error("Sorry, something wrong!", e);
		}
	}
	
	public  void waitForFreeResource()
	{
		resourceLock.waitForFreeResource();
	}
	
}
