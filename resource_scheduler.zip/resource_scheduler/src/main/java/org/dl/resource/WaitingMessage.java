package org.dl.resource;

import java.util.Iterator;
import java.util.LinkedList;

import org.dl.scheduler.Message;

//Object used as a Pool of received message
//Waiting to be picked up by a Worker

public class WaitingMessage {
	
	private LinkedList<Message> queue;
	private LinkedList<Message> historyQueue; //Used for testing
	private static WaitingMessage waitingMessage = null;
	
	ResourceLock resourceLock=ResourceLock.getInstance();
	
	public WaitingMessage()
	{
		queue=new LinkedList<Message>();
		historyQueue=new LinkedList<Message>();
	}
	
	public static synchronized  WaitingMessage getInstance()
	{			
		if (waitingMessage == null)
		{ 	waitingMessage = new WaitingMessage();	
		}
		return waitingMessage;
	}
	
	
	//Message get by the Workers
	public synchronized Message getMessage() throws InterruptedException 
	{
		while (queue.isEmpty()==true)
		{
			wait();
		}
		Message msg=(Message)queue.poll();
		System.out.println("RECEIVED FROM SCHEDULER Message ID->"+msg.getMessageId());
		
		return msg;
	}
	
	//Message added by the resource manager
	public synchronized void putMessage(Message msg) throws InterruptedException 
	{
		//One new resource busy
		resourceLock.removeResource();
		//System.out.println("ADD MESSAGE "+msg.getMessageId());
		queue.add(msg);
		historyQueue.add(msg);
		notifyAll();
	}
	
	public synchronized int getQueueSize()
	{
		return queue.size();
	}
	
	//for testing purpose
	public void Reset()
	{
		queue=new LinkedList<Message>();
	}
	
	//Return true if the message ID is in the historyQueue
	public boolean isInHistoryQueue(long messageId)
	{
		Iterator<Message> iteratorMessage=historyQueue.iterator();
		while(iteratorMessage.hasNext())
		{
			Message msg=iteratorMessage.next();
			if (msg.getMessageId()==messageId)
			{
				return true;
			}
		}
		return false;
	}
	
	//return true if the message in present and in the position "position"
	public boolean isInHistoryQueueAndPosition(long messageId, int position)
	{
		Message msg=null;
		Iterator<Message> iteratorMessage=historyQueue.iterator();
		int pos=0;
		while(iteratorMessage.hasNext() && pos<position )
		{
			msg=iteratorMessage.next();
			pos++;
		}
		if (msg!=null &&  msg.getMessageId()==messageId)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	
}
