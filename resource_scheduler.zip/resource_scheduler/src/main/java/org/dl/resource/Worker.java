package org.dl.resource;

import org.apache.log4j.Logger;
import org.dl.scheduler.Message;

//Thread that performs the work with the message
public class Worker extends Thread
{
	//private ShareMessage shareMessage;
	private int id;
	ResourceLock resourceLock=ResourceLock.getInstance();
	WaitingMessage waitingMessage=WaitingMessage.getInstance();
	
	final static Logger log = Logger.getLogger(Worker.class.getName());
	
	public Worker(int id)
	{
		this.id=id;
	}
	
	public synchronized void run ()
	{ 
		try
	    {
			
			System.out.println("Thread "+id+" Started");
			//One resource is now available
			resourceLock.addResource(); 
			notifyAll(); //Wakes up the scheduler waiting for a resource
			log.debug("Thread "+id+" Started");
			
			while (!interrupted())
			{ 
				//System.out.println("Available Resource ="+resourceLock.getResourceAvailable());
				Message msg=waitingMessage.getMessage();
				
				//Used to increase the duration to perform the job with the message
				double work_duration=100 + Math.random()*100;
				sleep ((long) work_duration);
				
				msg.completed();
				
				//One resource is now available
				resourceLock.addResource();
				notifyAll(); //Wakes up the scheduler waiting to send a message
			}
	    }
	    catch (InterruptedException e) {
	    	log.debug("END OF WORKER!", e);
	    }
	 }
	
	
}
