package org.dl.resource;

import org.dl.scheduler.Message;

public interface Gateway {
	public void send(Message msg);
	public void waitForFreeResource();
	public void startResource();
	public void stopResource();
}
