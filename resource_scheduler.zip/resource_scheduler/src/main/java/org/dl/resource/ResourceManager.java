package org.dl.resource;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.dl.scheduler.Message;

//manager the Pool of Thread worker 
public class ResourceManager {

	private int nb_resource;
	private   ExecutorService pool;
	
	WaitingMessage waitingMessage=WaitingMessage.getInstance();
	
	final static Logger log = Logger.getLogger(ResourceManager.class.getName());
	
	public ResourceManager(int resourceAvailable)
	{
		this.nb_resource=resourceAvailable;
		if (nb_resource>0)
		{
			pool = Executors.newFixedThreadPool(nb_resource);
		}
		waitingMessage.Reset();
	}
	
	//receive message form the scheduler via the gateway
	public synchronized void receiveMessage(Message msg) throws InterruptedException
	{
		waitingMessage.putMessage(msg);
	}
		
	public void start_work()
	{
		for (int i=0;i<nb_resource;i++)
		{
			pool.submit(new Worker(i));
		}
	}
	
	public void stop_work()
	{
	   pool.shutdown(); // Disable new tasks from being submitted
	   try {
	     // Wait a while for existing tasks to terminate
	     if (!pool.awaitTermination(1, TimeUnit.SECONDS)) {
	       pool.shutdownNow(); // Cancel currently executing tasks
	       // Wait a while for tasks to respond to being cancelled
	       if (!pool.awaitTermination(1, TimeUnit.SECONDS))
	       {
	           System.err.println("Pool did not terminate");
	           log.error("Pool did not terminate");
	       }
	     }
	   } catch (InterruptedException ie) {
	     // (Re-)Cancel if current thread also interrupted
	     pool.shutdownNow();
	     // Preserve interrupt status
	     Thread.currentThread().interrupt();
	   }
	   System.out.println("ResourceManager stopped");
	}
	
	
	
	public synchronized int getQueueSize()
	{
		return waitingMessage.getQueueSize();
	}
	
}
